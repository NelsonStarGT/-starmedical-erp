"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { actionSetClientsConfigRegistryDeprecated } from "@/app/admin/clientes/actions";
import ClientsConfigManagerDrawer from "@/components/clients/config/ClientsConfigManagerDrawer";
import ClientsConfigManagerRenderer, { type ClientsConfigManagerPayload } from "@/components/clients/config/ClientsConfigManagerRenderer";
import { canDeprecateClientsConfigEntry, type ClientsConfigScope, type ClientsConfigSection, type ClientsConfigSourceState } from "@/lib/clients/clientsConfigRegistry";
import { cn } from "@/lib/utils";

export type ClientsConfigOverviewRow = {
  key: string;
  label: string;
  section: Exclude<ClientsConfigSection, "resumen">;
  scope: ClientsConfigScope;
  usedBy: string[];
  dependsOn: string[];
  managerComponentId: string;
  canDeprecate: boolean;
  deprecated: boolean;
  source: ClientsConfigSourceState;
  activeItems: number;
  inactiveItems: number;
};

const SECTION_LABELS: Record<Exclude<ClientsConfigSection, "resumen">, string> = {
  catalogos: "Catálogos",
  directorios: "Directorios",
  canales: "Canales",
  reglas: "Reglas",
  validaciones: "Validaciones",
  futuro: "Futuro"
};

const SOURCE_BADGE_STYLES: Record<ClientsConfigSourceState, string> = {
  db: "border-emerald-200 bg-emerald-50 text-emerald-700",
  fallback: "border-amber-200 bg-amber-50 text-amber-700",
  defaults: "border-amber-200 bg-amber-50 text-amber-700",
  "n/a": "border-slate-200 bg-slate-100 text-slate-600"
};

const SCOPE_LABELS: Record<ClientsConfigScope, string> = {
  tenant: "Tenant",
  shared: "Compartido",
  legacy: "Legacy",
  future: "Futuro"
};

export default function ClientsConfigOverview({
  rows,
  payload
}: {
  rows: ClientsConfigOverviewRow[];
  payload: ClientsConfigManagerPayload;
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  const [query, setQuery] = useState("");
  const [sectionFilter, setSectionFilter] = useState<"all" | Exclude<ClientsConfigSection, "resumen">>("all");
  const [scopeFilter, setScopeFilter] = useState<"all" | ClientsConfigScope>("all");
  const [statusFilter, setStatusFilter] = useState<"all" | ClientsConfigSourceState>("all");
  const [usedByFilter, setUsedByFilter] = useState<"all" | "used" | "unused">("all");
  const [openKey, setOpenKey] = useState<string | null>(null);

  const openRow = useMemo(() => rows.find((row) => row.key === openKey) ?? null, [openKey, rows]);

  const filteredRows = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return rows.filter((row) => {
      if (sectionFilter !== "all" && row.section !== sectionFilter) return false;
      if (scopeFilter !== "all" && row.scope !== scopeFilter) return false;
      if (statusFilter !== "all" && row.source !== statusFilter) return false;
      if (usedByFilter === "used" && row.usedBy.length === 0) return false;
      if (usedByFilter === "unused" && row.usedBy.length > 0) return false;
      if (!needle) return true;
      const haystack = `${row.label} ${row.key} ${row.usedBy.join(" ")} ${row.dependsOn.join(" ")}`.toLowerCase();
      return haystack.includes(needle);
    });
  }, [query, rows, scopeFilter, sectionFilter, statusFilter, usedByFilter]);

  const summary = useMemo(() => {
    return {
      total: rows.length,
      deprecated: rows.filter((row) => row.deprecated).length,
      fallback: rows.filter((row) => row.source === "fallback" || row.source === "defaults").length
    };
  }, [rows]);

  const setDeprecated = (row: ClientsConfigOverviewRow, deprecated: boolean) => {
    startTransition(async () => {
      try {
        await actionSetClientsConfigRegistryDeprecated({ key: row.key, deprecated });
        setError(null);
        router.refresh();
      } catch (err) {
        setError((err as Error)?.message || "No se pudo actualizar estado deprecado.");
      }
    });
  };

  return (
    <div className="space-y-4">
      <section className="rounded-xl border border-[#dce7f5] bg-white p-4 shadow-sm">
        <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-[#2e75ba]">Autoguía</p>
        <p className="mt-1 text-sm text-slate-600">
          1) filtra por sección/uso, 2) abre el manager en panel lateral, 3) marca como deprecado solo catálogos sin uso activo.
        </p>
        <p className="mt-2 text-xs text-slate-500">
          Total: <span className="font-semibold text-slate-700">{summary.total}</span> · Deprecados:{" "}
          <span className="font-semibold text-slate-700">{summary.deprecated}</span> · Fallback activo:{" "}
          <span className="font-semibold text-slate-700">{summary.fallback}</span>
        </p>
      </section>

      <section className="grid gap-2 rounded-xl border border-[#dce7f5] bg-white p-4 shadow-sm md:grid-cols-2 xl:grid-cols-5">
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Buscar nombre, key, dependencia..."
          className="h-11 rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-700 shadow-sm focus:border-[#4aa59c] focus:outline-none focus:ring-2 focus:ring-[#4aa59c]/25 xl:col-span-2"
        />
        <SelectFilter
          label="Sección"
          value={sectionFilter}
          onChange={(value) => setSectionFilter(value as typeof sectionFilter)}
          options={[
            { value: "all", label: "Todas" },
            { value: "catalogos", label: "Catálogos" },
            { value: "directorios", label: "Directorios" },
            { value: "canales", label: "Canales" },
            { value: "reglas", label: "Reglas" },
            { value: "validaciones", label: "Validaciones" },
            { value: "futuro", label: "Futuro" }
          ]}
        />
        <SelectFilter
          label="Scope"
          value={scopeFilter}
          onChange={(value) => setScopeFilter(value as typeof scopeFilter)}
          options={[
            { value: "all", label: "Todos" },
            { value: "tenant", label: "Tenant" },
            { value: "shared", label: "Compartido" },
            { value: "legacy", label: "Legacy" },
            { value: "future", label: "Futuro" }
          ]}
        />
        <div className="grid gap-2 md:grid-cols-2 xl:col-span-1 xl:grid-cols-1">
          <SelectFilter
            label="Estado"
            value={statusFilter}
            onChange={(value) => setStatusFilter(value as typeof statusFilter)}
            options={[
              { value: "all", label: "Todos" },
              { value: "db", label: "DB" },
              { value: "fallback", label: "Fallback" },
              { value: "defaults", label: "Defaults" },
              { value: "n/a", label: "N/A" }
            ]}
          />
          <SelectFilter
            label="Uso"
            value={usedByFilter}
            onChange={(value) => setUsedByFilter(value as typeof usedByFilter)}
            options={[
              { value: "all", label: "Todos" },
              { value: "used", label: "Con uso" },
              { value: "unused", label: "Sin uso" }
            ]}
          />
        </div>
      </section>

      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        <table className="min-w-full text-sm">
          <thead className="bg-[#f8fafc] text-[#2e75ba]">
            <tr>
              <th className="px-3 py-2 text-left font-semibold">Nombre</th>
              <th className="px-3 py-2 text-left font-semibold">Sección</th>
              <th className="px-3 py-2 text-left font-semibold">Scope</th>
              <th className="px-3 py-2 text-left font-semibold">Usado en</th>
              <th className="px-3 py-2 text-left font-semibold">Estado</th>
              <th className="px-3 py-2 text-left font-semibold">Items (act/inact)</th>
              <th className="px-3 py-2 text-left font-semibold">Dependencias</th>
              <th className="px-3 py-2 text-right font-semibold">Acción</th>
            </tr>
          </thead>
          <tbody>
            {filteredRows.map((row, index) => {
              const canDeprecate = canDeprecateClientsConfigEntry(row);
              return (
                <tr key={row.key} className={index % 2 ? "bg-slate-50/60" : "bg-white"}>
                  <td className="px-3 py-2">
                    <p className="font-semibold text-slate-900">{row.label}</p>
                    <p className="font-mono text-[11px] text-slate-500">{row.key}</p>
                    {row.deprecated ? (
                      <span className="mt-1 inline-flex rounded-full border border-rose-200 bg-rose-50 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-rose-700">
                        Deprecado
                      </span>
                    ) : null}
                  </td>
                  <td className="px-3 py-2 text-slate-600">{SECTION_LABELS[row.section]}</td>
                  <td className="px-3 py-2 text-slate-600">{SCOPE_LABELS[row.scope]}</td>
                  <td className="px-3 py-2 text-xs text-slate-600">{row.usedBy.length ? row.usedBy.join(" · ") : "Sin uso"}</td>
                  <td className="px-3 py-2">
                    <span
                      className={cn(
                        "inline-flex rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.12em]",
                        SOURCE_BADGE_STYLES[row.source]
                      )}
                    >
                      {row.source}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-slate-700">
                    {row.activeItems}/{row.inactiveItems}
                  </td>
                  <td className="px-3 py-2 text-xs text-slate-600">{row.dependsOn.length ? row.dependsOn.join(" · ") : "—"}</td>
                  <td className="px-3 py-2">
                    <div className="flex flex-wrap justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setOpenKey(row.key)}
                        className="inline-flex h-9 items-center rounded-lg border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700 hover:border-[#4aadf5] hover:text-[#2e75ba]"
                      >
                        Abrir
                      </button>
                      {row.deprecated ? (
                        <button
                          type="button"
                          onClick={() => setDeprecated(row, false)}
                          disabled={isPending}
                          className="inline-flex h-9 items-center rounded-lg border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700 hover:border-[#4aadf5] hover:text-[#2e75ba] disabled:cursor-not-allowed disabled:opacity-60"
                        >
                          Rehabilitar
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setDeprecated(row, true)}
                          disabled={isPending || !canDeprecate}
                          className="inline-flex h-9 items-center rounded-lg border border-amber-200 bg-amber-50 px-3 text-xs font-semibold text-amber-800 hover:border-amber-300 disabled:cursor-not-allowed disabled:opacity-60"
                          title={!canDeprecate ? "Solo aplica para entradas sin uso activo." : undefined}
                        >
                          Marcar deprecado
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
            {!filteredRows.length ? (
              <tr>
                <td colSpan={8} className="px-3 py-4 text-center text-xs text-slate-500">
                  Sin resultados para los filtros actuales.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </section>

      {error ? <div className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-700">{error}</div> : null}

      <ClientsConfigManagerDrawer
        open={Boolean(openRow)}
        onClose={() => setOpenKey(null)}
        title={openRow?.label ?? "Manager"}
        subtitle={openRow ? `${SECTION_LABELS[openRow.section]} · ${SCOPE_LABELS[openRow.scope]}` : undefined}
      >
        {openRow ? <ClientsConfigManagerRenderer managerComponentId={openRow.managerComponentId} payload={payload} /> : null}
      </ClientsConfigManagerDrawer>
    </div>
  );
}

function SelectFilter({
  label,
  value,
  onChange,
  options
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: Array<{ value: string; label: string }>;
}) {
  return (
    <label className="space-y-1 text-xs font-semibold text-slate-500">
      {label}
      <select
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm font-medium text-slate-700 shadow-sm focus:border-[#4aa59c] focus:outline-none focus:ring-2 focus:ring-[#4aa59c]/25"
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </label>
  );
}
