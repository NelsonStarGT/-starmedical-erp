"use client";

import { useMemo, useState } from "react";
import SearchableSelect from "@/components/ui/SearchableSelect";
import ClientsConfigManagerRenderer, { type ClientsConfigManagerPayload } from "@/components/clients/config/ClientsConfigManagerRenderer";
import type { ClientsConfigSourceState } from "@/lib/clients/clientsConfigRegistry";
import { cn } from "@/lib/utils";

type CatalogEntry = {
  key: string;
  label: string;
  managerComponentId: string;
  source: ClientsConfigSourceState;
  activeItems: number;
  inactiveItems: number;
};

const SOURCE_BADGE_STYLES: Record<ClientsConfigSourceState, string> = {
  db: "border-emerald-200 bg-emerald-50 text-emerald-700",
  fallback: "border-amber-200 bg-amber-50 text-amber-700",
  defaults: "border-amber-200 bg-amber-50 text-amber-700",
  "n/a": "border-slate-200 bg-slate-100 text-slate-600"
};

export default function ClientsConfigCatalogFocus({
  entries,
  payload
}: {
  entries: CatalogEntry[];
  payload: ClientsConfigManagerPayload;
}) {
  const [selectedKey, setSelectedKey] = useState(entries[0]?.key ?? "");
  const [gridMode, setGridMode] = useState(false);

  const selectedEntry = useMemo(() => entries.find((entry) => entry.key === selectedKey) ?? entries[0] ?? null, [entries, selectedKey]);

  return (
    <div className="space-y-4">
      <section className="rounded-xl border border-[#dce7f5] bg-white p-4 shadow-sm">
        <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-[#2e75ba]">Autoguía</p>
        <p className="mt-1 text-sm text-slate-600">
          Selecciona un catálogo y enfócate en un solo manager. Activa modo grid solo cuando necesites una vista amplia.
        </p>
      </section>

      <section className="grid gap-3 rounded-xl border border-[#dce7f5] bg-white p-4 shadow-sm lg:grid-cols-[minmax(0,1fr)_auto]">
        <SearchableSelect
          value={selectedEntry?.key ?? ""}
          onChange={setSelectedKey}
          options={entries.map((entry) => ({
            id: entry.key,
            label: `${entry.label} (${entry.activeItems}/${entry.inactiveItems})`
          }))}
          placeholder="Selecciona catálogo"
          disabled={entries.length === 0}
        />
        <button
          type="button"
          onClick={() => setGridMode((prev) => !prev)}
          className="inline-flex h-11 items-center justify-center rounded-xl border border-slate-200 bg-white px-4 text-sm font-semibold text-slate-700 hover:border-[#4aadf5] hover:text-[#2e75ba]"
        >
          {gridMode ? "Ver modo foco" : "Ver modo grid"}
        </button>
      </section>

      {!entries.length ? (
        <section className="rounded-xl border border-slate-200 bg-white p-4 text-sm text-slate-600 shadow-sm">
          No hay catálogos visibles. Revisa si fueron marcados como deprecados en Resumen.
        </section>
      ) : null}

      {gridMode ? (
        <div className="grid gap-4 xl:grid-cols-2">
          {entries.map((entry) => (
            <section key={entry.key} className="space-y-2">
              <div className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 shadow-sm">
                <p className="text-sm font-semibold text-slate-800">{entry.label}</p>
                <div className="flex items-center gap-2">
                  <span
                    className={cn(
                      "rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.12em]",
                      SOURCE_BADGE_STYLES[entry.source]
                    )}
                  >
                    {entry.source}
                  </span>
                  <span className="text-xs text-slate-500">
                    {entry.activeItems}/{entry.inactiveItems}
                  </span>
                </div>
              </div>
              <ClientsConfigManagerRenderer managerComponentId={entry.managerComponentId} payload={payload} />
            </section>
          ))}
        </div>
      ) : selectedEntry ? (
        <div className="space-y-2">
          <div className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 shadow-sm">
            <p className="text-sm font-semibold text-slate-800">{selectedEntry.label}</p>
            <div className="flex items-center gap-2">
              <span
                className={cn(
                  "rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.12em]",
                  SOURCE_BADGE_STYLES[selectedEntry.source]
                )}
              >
                {selectedEntry.source}
              </span>
              <span className="text-xs text-slate-500">
                {selectedEntry.activeItems}/{selectedEntry.inactiveItems}
              </span>
            </div>
          </div>
          <ClientsConfigManagerRenderer managerComponentId={selectedEntry.managerComponentId} payload={payload} />
        </div>
      ) : null}
    </div>
  );
}
